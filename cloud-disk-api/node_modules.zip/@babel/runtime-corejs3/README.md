# @babel/runtime-corejs3

> babel's modular runtime helpers with core-js@3 polyfilling

## Install

Using npm:

```sh
npm install --save-dev @babel/runtime-corejs3
```

or using yarn:

```sh
yarn add @babel/runtime-corejs3 --dev
```
